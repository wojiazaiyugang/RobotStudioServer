from robot_python.robot import Robot


def run_rpc_server():
    """
    启动RPC Server
    :return:
    """
    pass
